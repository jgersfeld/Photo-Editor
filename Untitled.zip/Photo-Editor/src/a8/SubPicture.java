package a8;

public interface SubPicture extends Picture {

	Picture getSource();
	int getXOffset();
	int getYOffset();
}
